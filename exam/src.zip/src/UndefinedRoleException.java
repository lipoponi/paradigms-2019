public class UndefinedRoleException extends RuntimeException {

}
