public interface Player {
    void setRole(CellFilling role);

    void makeMove(BoardConfiguration configuration);
}
